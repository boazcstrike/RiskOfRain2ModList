#EngineerPlus

	╔════════════════════════════════════════════════════════════════════════════════════════════════════╗
	║Allows you to change the amount of turrets, mines and shields each engineer can place in your lobby.║ 
	║Allows you to customize the mine explosion radius and the engineer bubbleshield duration. 			 ║
	║Enemies killed by engineer turrets now also have the chance to drop lunar coins.                    ║
	║																									 ║
	║ Working for singleplayer and multiplayer.                                                          ║
	╚════════════════════════════════════════════════════════════════════════════════════════════════════╝
	╔══════════════════════════════════════════════════════════════════════════╗
	║Change the skill base max charge count of the turret,mine and bubbleshield║
	║⮡(This applies only to the players who have the mod installed)			   ║
	╚══════════════════════════════════════════════════════════════════════════╝
	
	Fully configurable via config file.
	
![example](https://www.bilder-upload.eu/upload/258f28-1557081504.png)
	
#Config
	
	To change values in the config you have to start the game once with
	the .dll inserted so the config file gets generated.
	
![config](https://www.bilder-upload.eu/upload/66c72f-1557322357.png) 

#Installation
	
   Drop the EngineerPlus.dll into \BepInEx\Plugins\
   
#BugReport
	
   To report bugs pls message me via the offical modding discord.
   My username is dan8991iel.

#Patchnotes
	v 2.1.0
		Major fixes: 
			Fixed a bug where it could happen that the charge and skill 
			counter change wouldn't be applied.
	v 2.0.2
		Minor fixes: 
			Fixed the config picture. 
	v 2.0.1
		Minor fixes: 
			Fixed some misleading text in the config.
			Fixed some misleading text in the readme.
	v 2.0.0
		Added:
			The ability to increase the starting skill charge count(lobby host only).
		Major fixes: 
			Now working with "DropinMultiplayer".		
		Minor fixes: 
			Fixed some misleading typos in the config.
	v 1.0.3