# Changes in 1.1.2

* uploaded the correct dll now

# Changes in 1.1.1

* Implemented frost relic
* Fixed stun grenade fuckup

# Changes in 1.1.0

* Items that roll chance now show the clover bonus
* Rusty key now shows proper loot chances for item groups
* Less confusing stat text
