# Empty Chests Be Gone
##### by Elysium

I developed this simple mod because I felt sometimes it was not easy to determine if something had been looted at a glance, especially from far away.
Now any time someone opens a chest or barrel, the game will remove the object as soon as the animation is done. No more second guessing!

**Features:**

- Removes empty chests, money barrels, equipment barrels after they have been looted.

- Leaves shops and shrines alone, as those are fairly easy to determine if they have been used.

### Installation guide
Copy the BepInEx Folder to:
Risk of Rain2

###Changelog:
- v1.1.0, Added a small delay, Ported to BepInEx (Thanks Bepin!)

~Elysium