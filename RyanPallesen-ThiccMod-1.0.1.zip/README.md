# THICCMOD
Note; I make mods for fun. Please respect this and do not beg for additions/fixes.


Note; original mod by Kerver, Bepinex port by me. config is planned.


Removes the skirt from artificer, and the scarf from huntress. makes both thiccer.




Install: Have BepInEx 1.3.1, put this mod's .dll file in BepInEx/Plugins




CHANGELOG


1.0.1


fixed spelling errors


1.0.0


Made the mod