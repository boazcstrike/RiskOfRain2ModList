## NoBossNoWait

  - Makes the teleporter charge when every boss is killed
  - WIP message me @mister_name on discord on problems
  
# Installation
Drop BanditMod.dll into `\BepInEx\plugins\`