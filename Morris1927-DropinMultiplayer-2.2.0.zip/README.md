# DropinMultiplayer
Drop in multiplayer mod for Risk of Rain 2, join your friends mid-game!
Gives you items when you join late so you're not behind.
spawn_as command in the chat or console (Ctrl+alt+tilde) lets you spawn as a new character.
Typing player_list into the console will show you the list of players with their IDs.
You can specify which player gets transformed using their ID or name.
[CharacterBody list](https://pastebin.com/iQFVDmJS) for a list of things to turn into

### Commands
  1. Ctrl+alt+tilde
  2. spawn_as Commando
  3. spawn_as Lemurian
  4. player_list 
  5. spawn_as Huntress Morris1927
  6. spawn_as MULT 0

# Installation
 1. Extract "DropInMultiplayer.dll" from the zip file and place it into  "/Risk of Rain 2/BepInEx/plugins/DropInMultiplayer/" folder.
 2. Done

# Notes
### 2.2.0---
* spawn_as is no longer case-sensitive
* Added verbose messages to command inputs
* Added aliases. eg. you can type MULT or MUL-T instead of Toolbot, or Artificer instead of Mage

### 2.1.0---
* Added more config options
* By default, players will now not be automatically put into the game (config)
* Config to enable/disable only spawning as survivors
* Config to enable/disable whether spawn_as can be used while alive

### 2.0.2---
* Added config options
* Possibly(?) fixed a bug causing players to spawn with items they shouldn't have

### 2.0.1---
* Updated to work with newest build
* Changed spawnas to spawn_as

### 2.0.0---
* Ported to BepInEx
* Added in spawnas as a chat command
* Removed the need to add Body to the end of everything

### 1.1.0---
* Fixed games not starting
* Added ability to change other peoples character (Helps if someone else doesn't have the mod)
